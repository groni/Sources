audiothumbs-frameworks
======================

Thumbnail generator for audio files, ported to KF5.

Ported from: http://kde-look.org/content/show.php/AudioThumbs?content=145088
