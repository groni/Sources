#ifndef USBDEVICEMONITOR_MAC_P_H
#define USBDEVICEMONITOR_MAC_P_H

// Class with platform-specific data
class UsbDeviceMonitorPrivate
{
public:
    UsbDeviceMonitorPrivate();
    ~UsbDeviceMonitorPrivate();
};


#endif // USBDEVICEMONITOR_MAC_P_H
