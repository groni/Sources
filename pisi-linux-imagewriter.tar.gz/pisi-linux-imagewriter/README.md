Pisi Linux Image Writer

Pisi Linux Image Writer is a fork of the original Rosa Image Writer, i have change only the icons in the source package.
The docs and all other is original based at Rosa.

http://wiki.rosalab.com/en/index.php/Blog:ROSA_Planet/ROSA_Image_Writer

http://wiki.rosalab.ru/en/index.php/ROSA_ImageWriter
