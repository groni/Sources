/* AUDEX CDDA EXTRACTOR
 * Copyright (C) 2007-2015 Marco Nelles (audex@maniatek.com)
 * <http://userbase.kde.org/Audex>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QObject>
#include <QLabel>
#include <QComboBox>
#include <QTreeView>
#include <QDockWidget>
#include <QInputDialog>

#include <KXmlGuiWindow>
#include <KLocalizedString>
#include <KActionCollection>
#include <KStandardAction>
#include <QStatusBar>
#include <KConfigDialog>
#include <KCModuleLoader>
#include <QLineEdit>
#include <KComboBox>
#include <KTextEdit>
#include <QPushButton>
#include <KMessageBox>
#include <KCddb/Kcddb>
#include <KCddb/Client>
#include <KCddb/Cdinfo>

#include "utils/error.h"
#include "utils/cuesheetwriter.h"

#include "models/cddamodel.h"
#include "models/profilemodel.h"

#include "preferences.h"
#include "widgets/generalsettingswidget.h"
#include "widgets/devicewidget.h"
#include "widgets/profilewidget.h"
#include "widgets/remoteserversettingswidget.h"
#include "widgets/cddaheaderwidget.h"

#include "dialogs/extractingprogressdialog.h"
#include "dialogs/errordialog.h"

#include "utils/encoderassistant.h"

class MainWindow : public KXmlGuiWindow {

  Q_OBJECT

public:
  MainWindow(QWidget *parent = 0);
  ~MainWindow();

private:
  bool firstStart();

private Q_SLOTS:
  void eject();
  void cddb_lookup();
  void cddb_submit();
  void rip();
  void configure();

  void new_audio_disc_detected();
  void audio_disc_removed();

  void cddb_lookup_start();
  void cddb_lookup_done(const bool successful);

  void update_layout();

  void enable_layout(bool enabled);
  void enable_submit(bool enabled = true);
  void disable_submit();

  void configuration_updated(const QString& dialog_name);

  void current_profile_updated_from_ui(int row);
  void update_profile_action(int index);
  void update_profile_action();

  void split_titles();
  void swap_artists_and_titles();
  void capitalize();
  void auto_fill_artists();
  void toggle(const QModelIndex &idx);
  void resizeColumns();

  void select_all();
  void select_none();
  void invert_selection();

  void cdda_context_menu(const QPoint& pos);

  void selection_changed(const int num_selected);

private:
  CDDAModel *cdda_model;
  ProfileModel *profile_model;

  QLabel *profile_label;
  KComboBox *profile_combobox;

  void setup_actions();
  void setup_layout();

  QTreeView *cdda_tree_view;

  QDockWidget *cdda_header_dock;
  CDDAHeaderWidget *cdda_header_widget;

  bool layout_enabled;

  int current_profile_index;
  void set_profile(int profile_index);

};

#endif
