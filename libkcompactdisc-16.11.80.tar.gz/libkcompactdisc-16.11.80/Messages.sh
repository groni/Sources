#! /bin/sh
$XGETTEXT src/*.cpp -o $podir/libkcompactdisc.pot
