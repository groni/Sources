#ifndef KCMCDDBI18N_H
#define KCMCDDBI18N_H

#define TRANSLATION_DOMAIN "kcmcddb"
#include <KI18n/KLocalizedString>

#endif // KCMCDDBI18N_H
