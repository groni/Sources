#ifndef KCDDBI18N_H
#define KCDDBI18N_H

#define TRANSLATION_DOMAIN "libkcddb"
#include <KI18n/KLocalizedString>

#endif // KCDDBI18N_H
