TRaK5 (partial) textureset
License: MIT license
--------------------------
This textureset is (basically) part of TRaK5's textureset, but with a few modifications by Megagun.