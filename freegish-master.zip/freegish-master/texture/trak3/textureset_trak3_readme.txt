TRaK3 (partial) textureset
License: GPL/cc-by-sa
--------------------------
This textureset is (basically) part of TRaK3's textureset, but with a few modifications by Megagun (slopes were added).